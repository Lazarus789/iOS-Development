//
//  ResidenceViewController.swift
//  House
//
//  Created by Tanishq Babbar on 25/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit
import CoreData

class ResidenceViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate {
    
    var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>!
    
    @IBOutlet weak var tableview: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }

    
    @IBAction func addBarButtonPressed(_ sender: Any) {
    }
    
    

}
