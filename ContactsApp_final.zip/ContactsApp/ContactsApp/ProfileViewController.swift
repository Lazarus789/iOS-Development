//
//  ProfileViewController.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 11/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var dateOfBirthLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    var localContact: Contact!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateUI()
    }
    
    
    //MARK: UpdateUI
    func updateUI() {
        
        if localContact != nil {
            self.title = localContact.fullName
            phoneNumberLabel.text = "Phone: " + localContact.phoneNumber!
            dateOfBirthLabel.text = "Date of Birth: " + dateFormatter().string(from: localContact.dateOfBirth!)
            if localContact.avatar != nil {
                self.avatarImageView.image = UIImage(data: localContact.avatar!)  
            }
            if localContact.address != nil {
                self.addressLabel.text = "Address: " + localContact.address!
            }
        }
    }


}
