//
//  ViewController.swift
//  Login App
//
//  Created by Tanishq Babbar on 01/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var loginStatus: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loginStatus.text = ""
    }
    
    
    @IBAction func loginButton(_ sender: Any) {
        if ageTextField.text != "" {
            let age = Int(ageTextField.text!)
            loginStatus.text = result(age: age!)
        }else {
            loginStatus.text = "Invalid input"
        }
        
        
    }
    
    func result(age: Int) -> String {
        if age >= 18 {
            return("Login successful")
        }else {
            return("Login failed")
        }
    }
    

}

