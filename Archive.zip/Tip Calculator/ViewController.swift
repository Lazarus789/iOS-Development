//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Tanishq Babbar on 01/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var employeeTextField: UITextField!
    @IBOutlet weak var tipLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tipLabel.text = ""
    }
    
    @IBAction func calculateButton(_ sender: Any) {
        if amountTextField.text != "" && employeeTextField.text != "" {
            let amount = Double(amountTextField.text!)
            let no_of_employee = Int(employeeTextField.text!)
            tipLabel.text = "Each Employee gets \(calculateTip(amount: Double(amount!), employee: Int(no_of_employee!)))"
        }else {
            tipLabel.text = "Please enter valid input"
        }
        
    }
    
    func calculateTip(amount: Double, employee: Int) -> Double {
        var result: Double = 0;
        result = amount / Double(employee)
        return result
    }
    

}

