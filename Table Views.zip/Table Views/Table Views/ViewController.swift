//
//  ViewController.swift
//  Table Views
//
//  Created by Tanishq Babbar on 04/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    
    @IBOutlet weak var editButtonOutlet: UIButton!
    @IBOutlet weak var tableView: UITableView!
    var myProduct = ["Product1", "Product2", "Product3", "Product4", "Product5"]
    var drinks = ["Beer", "coke", "pepsi", "soda"]
    
    var isEditingTable = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func editButtonPressed(_ sender: Any) {
        isEditingTable = !isEditingTable
        if isEditingTable {
            editButtonOutlet.setTitle("Done", for: .normal)
        }else {
            editButtonOutlet.setTitle("Edit", for: .normal)
        }
        tableView.isEditing = isEditingTable
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return myProduct.count
        }else {
            return drinks.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        if indexPath.section == 0 {
            cell.textLabel?.text = myProduct[indexPath.row]
            cell.detailTextLabel?.text = "Section: \(indexPath.section), Row: \(indexPath.row)"
        }else {
            cell.textLabel?.text = drinks[indexPath.row]
            cell.detailTextLabel?.text = "Section: \(indexPath.section), Row: \(indexPath.row)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            print("Selected row \(myProduct[indexPath.row])")
        }else {
            print("Selected row \(drinks[indexPath.row])")
        }
        
    }
    
    func tableView(_ tableView :UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Products"
        }else {
            return "Drinks"
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
       /* if indexPath.section == 0 {
            return true
        }else {
            return false
        } */
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        print("Deleting \(indexPath)")
        if indexPath.section == 0 {
            myProduct.remove(at: indexPath.row)
        }else {
            drinks.remove(at: indexPath.row)
        }
        tableView.deselectRow(at: indexPath, animated: true)
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
       /* if indexPath.section == 0 {
            return true
        }else {
            return false
        } */
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        var tempProduct :String!
        if sourceIndexPath.section == 0 {
            tempProduct = myProduct[sourceIndexPath.row]
            myProduct.remove(at: sourceIndexPath.row)
        }else {
            tempProduct = drinks[sourceIndexPath.row]
            drinks.remove(at: sourceIndexPath.row)
        }
        if destinationIndexPath.section == 0 {
            myProduct.insert(tempProduct, at: destinationIndexPath.row)
        }else {
            drinks.insert(tempProduct, at: destinationIndexPath.row)
        }
        
        print("Products \(myProduct)")
        print("Drinks \(drinks)")
        
        tableView.reloadData()
    }

    
    


}

