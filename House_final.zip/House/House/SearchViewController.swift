//
//  SearchViewController.swift
//  House
//
//  Created by Tanishq Babbar on 28/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit
import CoreData

class SearchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var searchButtonOutlet: UIButton!
    @IBOutlet weak var searchtextField: UITextField!
    @IBOutlet weak var tableview: UITableView!
    
    var allResidents: [Resident] = []
    var isSearching = false
    

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchFromCD()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allResidents.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let resident = allResidents[indexPath.row]
        cell.textLabel?.text = resident.name
        return cell
    }
    

    @IBAction func searchButtonPressed(_ sender: Any) {
        isSearching = !isSearching
            if searchtextField.text != "" {
                if isSearching {
                    searchButtonOutlet.setTitle("Cancel", for: .normal)
                } else {
                    searchButtonOutlet.setTitle("Search", for: .normal)
                }
                let searchPredicate = NSPredicate(format: "name contains[c] %@", searchtextField.text!)
                fetchFromCD(predicate: searchPredicate)
            } else {
                searchButtonOutlet.setTitle("Cancel", for: .normal)
                fetchFromCD()
            }

            fetchFromCD()
        }

    
    
    func  fetchFromCD(predicate: NSPredicate? = nil) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Resident")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        fetchRequest.predicate = predicate
        let context = AppDelegate.context
        
        do {
            let result = try context.fetch(fetchRequest)
            allResidents = result as! [Resident]
            tableview.reloadData()
        } catch {
            print("error fetching residents")
        }
        
    }
}
    
    
    


