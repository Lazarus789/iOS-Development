//
//  SearchViewController.swift
//  House
//
//  Created by Tanishq Babbar on 28/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit
import CoreData

class ResidentsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate {

    
    @IBOutlet weak var tableView: UITableView!
    
    var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>!
    
    var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchFromCD()
        tableView.tableFooterView = UIView()

    }
    
    //MARK: TableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedResultsController.sections?[0].numberOfObjects ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let resident = fetchedResultsController.object(at: indexPath) as! Resident
        cell.textLabel?.text = resident.name
        
        return cell
    }

    //MARK: TableView Delegates
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        performSegue(withIdentifier: "residentsToResidentDetailSeg", sender: indexPath)
    }
    

    
    //MARK: IBActions
    
    @IBAction func addBarButtonPressed(_ sender: Any) {
        showAddItemAlertConroller(title: "Add Resident")
    }
    
    //MARK: Show AddItem view
    
    func showAddItemAlertConroller(title: String) {
        
        let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        
        alertController.addTextField { (_nameTextField) in
            
            _nameTextField.placeholder = "Name"
            self.nameTextField = _nameTextField
        }
        
        alertController.addAction(UIAlertAction(title: "Add", style: .default, handler: { (alert) in
            self.saveResident()
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
    }

    //MARK: Save Resident
    
    func saveResident() {
        
        if nameTextField.text != "" {
            
            let context = AppDelegate.context
            let resident = Resident(context: context)
            resident.name = nameTextField.text

            saveToCD()
        } else {
            print("Error, name is required")
        }
    }
    
    //MARK: SaveToCD
    
    func saveToCD() {
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }

    
    
    //MARK: FetchFromCD
    
    func fetchFromCD() {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Resident")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: AppDelegate.context, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("Error fetching residents \(error.localizedDescription)")
        }
    }
    
    //MARK: NSFetchedResultsControllerDelegate
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .automatic)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .automatic)
        case .update:
            tableView.reloadData()
        default:
            print("unknow type")
        }
    }
    

    //MARK: Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "residentsToResidentDetailSeg" {
            
            let indexPath = sender as! IndexPath
            let destinationVC = segue.destination as! ResidentsDetailViewController
            destinationVC.localResident = fetchedResultsController.object(at: indexPath) as! Resident
        }
    }
    


}
