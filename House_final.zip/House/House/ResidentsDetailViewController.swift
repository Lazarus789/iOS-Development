//
//  SearchViewController.swift
//  House
//
//  Created by Tanishq Babbar on 28/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ResidentsDetailViewController: UIViewController, HouseViewControllerDelegate {
    

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var addresstextField: UITextField!
    
    
    var localResident: Resident!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = localResident.name
        updateUI()
    }
    
    
    //MARK: IBAction
    @IBAction func addAddressButtonPressed(_ sender: Any) {
        
        let houseVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "houseVC") as! HouseViewController
        houseVC.didCameFromResidentsVC = true
        houseVC.delegate = self
        
        navigationController?.pushViewController(houseVC, animated: true)
    }
    
    @IBAction func editButtonPressed(_ sender: Any) {
        
        if nameTextField.text != "" {
            localResident.name = nameTextField.text
            saveToCoreData()
            navigationController?.popViewController(animated: true)
        } else {
            print("Name must be set")
        }
        
    }
    
    
    //MARK: Update UI
    func updateUI() {
        nameTextField.text = localResident.name
        addresstextField.text = localResident.house?.address
    }
    
    //MARK: HouseViewControllerDelegate
    func didAddHouse(house: House) {
        print("did add house")
        localResident.house = house
        updateUI()
        saveToCoreData()
    }
    
    //MARK: SaveToCD
    
    func saveToCoreData() {
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    



}
