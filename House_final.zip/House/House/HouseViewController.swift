//
//  SearchViewController.swift
//  House
//
//  Created by Tanishq Babbar on 28/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit
import CoreData

protocol HouseViewControllerDelegate {
    func didAddHouse(house: House)
}

class HouseViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate {

    @IBOutlet weak var tableView: UITableView!

    var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>!
    
    var nameTextField: UITextField!
    var addressTextField: UITextField!
    
    var delegate: HouseViewControllerDelegate?
    var didCameFromResidentsVC = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchFromCD()
        self.navigationItem.rightBarButtonItem?.isEnabled = !didCameFromResidentsVC
        
        tableView.tableFooterView = UIView()
    }
    
    
    //MARK: TableVieDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedResultsController.sections?[0].numberOfObjects ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let house = fetchedResultsController.object(at: indexPath) as! House
        
        cell.textLabel?.text = house.name
        cell.detailTextLabel?.text = house.address
        
        return cell
    }
    
    //MARK: TableViewDelegate
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            let objectToDelete = fetchedResultsController.object(at: indexPath) as! House
            
            AppDelegate.context.delete(objectToDelete)
            saveToCD()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if didCameFromResidentsVC {
            delegate?.didAddHouse(house: fetchedResultsController.object(at: indexPath) as! House)
            navigationController?.popViewController(animated: true)
        } else {
            performSegue(withIdentifier: "housestoHouseDetailSeg", sender: indexPath)
        }
        
    }

    

    //MARK: IBActions
    
    @IBAction func addBarButtonPressed(_ sender: Any) {

        showAddItemAlertConroller(title: "Add House")
    }
    
    //MARK: Show AddItem view
    
    func showAddItemAlertConroller(title: String) {
        
        let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        
        alertController.addTextField { (_nameTextField) in
            
            _nameTextField.placeholder = "Name"
            self.nameTextField = _nameTextField
        }

        alertController.addTextField { (_addressTextField) in
            _addressTextField.placeholder = "Address"
            self.addressTextField = _addressTextField
        }
        

        alertController.addAction(UIAlertAction(title: "Add", style: .default, handler: { (alert) in
            self.saveHouse()
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
    }
    

    //MARK: Save to CD
    func saveHouse() {
        
        if nameTextField.text != "" && addressTextField.text != "" {
            
            let context = AppDelegate.context
            let house = House(context: context)
            house.name = nameTextField.text
            house.address = addressTextField.text
            
            saveToCD()
        } else {
            print("all fields are required")
        }
    }
    

    //MARK: SaveToCD
    
    func saveToCD() {
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    

    //MARK: FetchFromCD
    func fetchFromCD() {
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "House")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: AppDelegate.context, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("error saving house \(error.localizedDescription)")
        }
    }
    
    
    //MARK: NSFetchedResultsControllerDelegate
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .automatic)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .automatic)
        case .update:
            tableView.reloadData()
        default:
            print("unknow type")
        }
    }
    
    //MARK: Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "housestoHouseDetailSeg" {
            
            let indexPath = sender as! IndexPath
            let destinationVC = segue.destination as! HouseDetailViewController
            destinationVC.localHouse = fetchedResultsController.object(at: indexPath) as! House
        }
    }
    



    


}
