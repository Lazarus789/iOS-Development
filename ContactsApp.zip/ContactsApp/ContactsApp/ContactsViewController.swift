//
//  ContactsViewController.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 10/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ContactsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    struct Contact {
        var name: String
        var surname: String
        var phonrNumber: Int
    }
    
    var allContacts: [Contact] = []
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    
    
    @IBAction func addBarButtonPressed(_ sender: Any) {
        print("add new item")
        showAlertController()
    }
    
    func showAlertController() {
        let alertController = UIAlertController(title: "Create New Contact", message: nil, preferredStyle: .alert)
        
        alertController.addTextField { (nameTextField) in
            nameTextField.placeholder = "Name"
        }
        alertController.addTextField { (surnameTextField) in
            surnameTextField.placeholder = "Surname"
        }
        alertController.addTextField { (phoneNumberTextField) in
            phoneNumberTextField.placeholder = "Phone"
            phoneNumberTextField.keyboardType = .numberPad
        }


        let saveButton = UIAlertAction(title: "Save", style: .default) { (action) in
            
        }
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            
        }
        alertController.addAction(saveButton)
        alertController.addAction(cancelButton)
        self.present(alertController, animated: true, completion: nil)
    }
    

    

}
