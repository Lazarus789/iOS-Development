//
//  AddContactTableViewController.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 11/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

protocol AddContactTableViewControllerDelegate {
    func didCreateContact(contact: Contact)
}

class AddContactTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var topView: UIView!
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var saveButtonOutlet: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var surnameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var dateOfBirthTextField: UITextField!
    @IBOutlet weak var addressTextView: UITextView!
    
    var delegate: AddContactTableViewControllerDelegate?
    
    var imagePicker = UIImagePickerController()
    var avatarImage: UIImage?
    var datePicker = UIDatePicker()
    var dateOfBirth: Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createDatePicker()
        imagePicker.delegate = self
        tableView.tableFooterView = UIView()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 20
        }
        return 0
    }
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func saveButtonPressed(_ sender: Any) {
        if nameTextField.text != "" && surnameTextField.text != "" && phoneNumberTextField.text != "" {
            createNewContact()
        } else {
            showWarning(title: "Warning!", text: "Insert all the required info")
        }
    }
    
    
    @IBAction func cameraTapped(_ sender: Any) {
        showAlert()
    }
    
    @objc func datePickerChangedValue() {
        dateOfBirth = datePicker.date
        let dateString = dateFormatter().string(from: datePicker.date)
        dateOfBirthTextField.text = dateString
    }
    
    func showAlert() {
        let alert = UIAlertController(title: "Choose Avatar", message: nil, preferredStyle: .actionSheet)
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (alert) in
            self.showCamera()
        }
        
        let galleryAction = UIAlertAction(title: "Gallery", style: .default) { (alert) in
            self.showGallery()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = avatarImageView
            alert.popoverPresentationController?.sourceRect = avatarImageView.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func showCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            showWarning(title: "Warning!", text: "No camera found")
        }
        
    }
    
    func showWarning(title: String, text: String?) {
        let alert = UIAlertController(title: title, message: text, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showGallery() {
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func createDatePicker() {
        datePicker.datePickerMode = .date
        dateOfBirthTextField.inputView = datePicker
        datePicker.addTarget(self, action: #selector(self.datePickerChangedValue), for: .valueChanged)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let tempImage = info[.originalImage] {
            avatarImage = tempImage as? UIImage
            avatarImageView.contentMode = .scaleAspectFit
            avatarImageView.image = avatarImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func createNewContact() {
        let newContact = Contact(_name: self.nameTextField.text!, _surname: self.surnameTextField.text!, _phoneNumber: self.phoneNumberTextField.text!)
        if avatarImage != nil {
            newContact.avatar = avatarImage
        }
        if addressTextView.text != "" {
            newContact.address = addressTextView.text
        }
        
        if dateOfBirth != nil {
            newContact.dateOfBirth = dateOfBirth!
         }
        
        delegate!.didCreateContact(contact: newContact)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
}
