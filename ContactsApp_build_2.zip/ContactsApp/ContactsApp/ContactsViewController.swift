//
//  ContactsViewController.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 11/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class ContactsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddContactTableViewControllerDelegate {
    
    
    
    
    var allContacts: [Contact] = []
    
    var nameTextField: UITextField!
    var surnameTextField: UITextField!
    var phoneNumberTextField: UITextField!

    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.tableFooterView = UIView()
        
    }
    
    //MARK: TableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allContacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! ContactTableViewCell
        
        let myContact = allContacts[indexPath.row]
        
        cell.setupCell(contact: myContact)
        
        return cell
    }

    
    //MARK: TableViewDelegate
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        performSegue(withIdentifier: "contactsToProfileSeg", sender: indexPath)
    }
    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        allContacts.remove(at: indexPath.row)
        tableView.reloadData()
    }
        
    

    //MARK: Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "contactsToProfileSeg" {
            
            let indexPath = sender as! IndexPath
            
            let tempContact = allContacts[indexPath.row]

            let profileVC = segue.destination as! ProfileViewController

            profileVC.localContact = tempContact
        }
        
        if segue.identifier == "contactsToAddContactSeg" {
            let addContactVC = segue.destination as! AddContactTableViewController
            addContactVC.delegate = self
        }
        
    }
    

    //MARK: AddContactTableViewControllerDelegate
    func didCreateContact(contact: Contact) {
        allContacts.append(contact)
        tableView.reloadData()
    }
    
    

    

    



}
