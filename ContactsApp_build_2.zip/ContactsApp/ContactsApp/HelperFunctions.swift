//
//  HelperFunctions.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 12/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import Foundation

let dateFormat = "dd/MM/yyyy"
func dateFormatter() -> DateFormatter {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = dateFormat
    return dateFormatter
}





