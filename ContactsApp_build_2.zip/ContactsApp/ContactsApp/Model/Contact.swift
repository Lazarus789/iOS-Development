//
//  Contact.swift
//  ContactsApp
//
//  Created by Tanishq Babbar on 11/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import Foundation
import UIKit

class Contact {
    
    var name: String
    var surname: String
    var fullName: String
    var phoneNumber: String
    var dateOfBirth: Date
    var avatar: UIImage?
    var address: String?
    
    init(_name: String, _surname: String, _phoneNumber: String) {
        
        name = _name
        surname = _surname
        fullName = name + " " + surname
        phoneNumber = _phoneNumber
        dateOfBirth = Date()
    }
    

}
