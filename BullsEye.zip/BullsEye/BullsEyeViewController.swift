//
//  BullsEyeViewController.swift
//  BullsEye
//
//  Created by Tanishq Babbar on 03/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class BullsEyeViewController: UIViewController {
    
    
    @IBOutlet weak var targetLabel: UILabel!
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var readyButtonOutlet: UIButton!
    
    var randomNumber = 0.0
    var isCheaterModeOn: Bool?
    var highestScore: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        highestScore = UserDefaults.standard.double(forKey: "myHighestScore")
        print("my current high score is \(highestScore!)")
        
        if isCheaterModeOn != nil {
            print("we are in cheater mode \(isCheaterModeOn!)")
        }
        generateRandomNumber()
        targetLabel.text = String(format: "Your Target is: %.2f", randomNumber)

       
    }
    
    @IBAction func readyButtonPressed(_ sender: Any) {
        checkTarget(target: randomNumber, result: Double(sliderOutlet.value))
        resultLabel.text = ("")
    }
    
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        if isCheaterModeOn != nil {
            if isCheaterModeOn! {
            resultLabel.text = String(format: "%.2f", sender.value)
                }
        }
    }
    
    
    @IBAction func backButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func checkTarget(target: Double, result: Double) {
        
        let startingPoint = target - 4
        let endPoint = target + 4
        
        if (result >= startingPoint) && (result <= endPoint) {
            
            getCurrentHighScore(target: target, result: result)
            
            showResult(title: "Bull's Eye!!", message: String(format: "You hit %.2f", sliderOutlet.value))
        }else {
            showResult(title: "Looser!!", message: String(format: "You hit %.2f", sliderOutlet.value))
        }
        
    }
    
    func generateRandomNumber() {
        randomNumber = Double.random(in: 0...100)
    }
    
    func updateUI() {
        generateRandomNumber()
        targetLabel.text = String(format: "Your Target is: %.2f", randomNumber)
        sliderOutlet.value = 0
    }
    
    func showResult(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK", style: .default) { (action) in
            self.updateUI()
        }
        
        alertController.addAction(okButton)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func getCurrentHighScore(target: Double, result: Double) {
        var currentScore: Double!
        if target > result {
        currentScore = target - result
        }else {
            currentScore = result - target
        }
        compareHighScore(currentScore: currentScore)
    }
    
    func compareHighScore(currentScore: Double) {
        if highestScore != nil {
            if highestScore! > currentScore {
                highestScore = currentScore
                showResult(title: "New Record!", message: String(format: "Your new record is: %.2f", highestScore!))
                
                UserDefaults.standard.set(highestScore!, forKey: "myHighestScore")
                UserDefaults.standard.synchronize()
            }
        }else {
            highestScore = currentScore
        }
    }
    

    

}
