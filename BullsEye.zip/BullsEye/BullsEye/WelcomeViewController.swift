//
//  WelcomeViewController.swift
//  BullsEye
//
//  Created by Tanishq Babbar on 03/12/19.
//  Copyright © 2019 Tanishq Babbar. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    
    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var showHighScoreButtonOutlet: UIButton!
    
    var isCheaterModeON = false
    var isShowingScore = false

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func playButtonPressed(_ sender: UIButton) {
        performSegue(withIdentifier: "welcomeToGameSeg", sender: self)
    }
    
    @IBAction func cheaterSwitchChangedValue(_ sender: UISwitch) {
        isCheaterModeON = sender.isOn
        print(isCheaterModeON)
    }
    
    
    @IBAction func showHighScore(_ sender: Any) {
        isShowingScore = !isShowingScore
        if isShowingScore {
            showHighScoreButtonOutlet.setTitle("Hide high score", for: .normal)
            let myhighScore = UserDefaults.standard.double(forKey: "myHighestScore")
            scoreLabel.text = String(format: "Score: %.2f", myhighScore)
        }else {
            showHighScoreButtonOutlet.setTitle("Show high score", for: .normal)
            scoreLabel.text = ""
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "welcomeToGameSeg" {
            let gameVC = segue.destination as! BullsEyeViewController
            gameVC.isCheaterModeOn = isCheaterModeON
            self.present(gameVC, animated: true, completion: nil)
        }
        
        
    }
    

    

}
